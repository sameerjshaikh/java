package sameer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class IPLTICKETBOOKING {
	
	final static String url = "jdbc:mysql://localhost/IPL";
	final static String user = "root";
	final static String pwd = "root";
	
	public static int ticketNO=1;
	
	
	private static Scanner snc = new Scanner(System.in);
	
	static Connection getConnection() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, pwd);
		return con;
	}	
	
	public static void main(String[] args) {
		int choice;
		try {
			do {	
				MyConsole.print("KSCA Chinnaswamy Stadium in Bangalore");
				MyConsole.print("1.Issue Ticket\n2.Total No of Ticket BookEd\n3.Statistics of game");
				choice =snc.nextInt();
				switch(choice)
				{
				case 1:
						issueTicket();
						break;
				case 2:		
					
						totalTicket();

					break;
				case 3:
					StatisticsOfgame();
				
				}
				
			}while(choice!=4);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void issueTicket()
	{
			String name=MyConsole.getString("Enter name");
			String categ=MyConsole.getString("\nEnter Categery\n1.male\n2Female\n2Children");
			
			int matchId =MyConsole.getNumber("\nSelect Match\n1.BLR vs KKR.\n2.BLR VS CSK 3.BLR VS MUBAI\n");
			MyConsole.print("\nselect stand \n 1.Kumble stand.\n2.Rahul Dravid Stand.\n3GR Vishwanath Stand");
			int standId = snc.nextInt();
			
			
			try {
				Connection con = getConnection();
				Statement query = con.createStatement();
				String insert = String.format("insert into IPLTICKET(CNAME,CCATG,MATCHID,STANDID) values('%s','%d','%d','5d')", name,categ,matchId,standId );
				int rowsAffected = query.executeUpdate(insert);		
			}
			catch (Exception e) 
			{
				MyConsole.print(e);
			}
			MyConsole.print("Your ticket No is ="+ticketNO);
			ticketNO++;
		}
	public static void totalTicket() throws Exception
	{
		MyConsole.print("\nselect stand to find total no of ticket\n 1.Kumble stand.\n2.Rahul Dravid Stand.\n3GR Vishwanath Stand");
		int standId=snc.nextInt();
		Connection con = getConnection();
		String query = "select STANDID  WHERE STANDID=? from IPLTICKET";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1,standId);
		int rowsAffected = ps.executeUpdate();
		
		MyConsole.print("The  Count of Satnd is="+rowsAffected);
	}
	public static void StatisticsOfgame() throws Exception
	{
		int matchId =MyConsole.getNumber("\nSelect Match\n1.BLR vs KKR.\n2.BLR VS CSK 3.BLR VS MUBAI\n");
		Connection con = getConnection();
		String querymale = "select CCATG where MTCHID=? & CCATG=1 FROM IPLTICKET";
		PreparedStatement ps = con.prepareStatement(querymale);
		ps.setInt(1,matchId);
		int rowsquerymale = ps.executeUpdate();
		String queryfemale = "select CCATG where MTCHID=? & CCATG=1 FROM IPLTICKET";
		PreparedStatement ps1 = con.prepareStatement(querymale);
		ps1.setInt(1,matchId);
		int rowsqueryfemale = ps1.executeUpdate();
		String querychi = "select CCATG where MTCHID=? & CCATG=1 FROM IPLTICKET";
		PreparedStatement ps2 = con.prepareStatement(querymale);
		ps2.setInt(1,matchId);
		int rowsquerchi = ps2.executeUpdate();
		
		MyConsole.print("\n-------Statistics--------");
		MyConsole.print("\nmale:"+rowsquerymale);
		MyConsole.print("\nFemale:"+rowsqueryfemale);
		MyConsole.print("\nChildren:"+rowsquerchi);
		
		
		
		
		
		
		
		
	}
			
	
	
			
			
		
	}

	
	


